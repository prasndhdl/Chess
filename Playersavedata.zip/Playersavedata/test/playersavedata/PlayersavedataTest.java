/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playersavedata;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Prashant Dhaubhadel
 */

  
public class PlayersavedataTest {
    
    public PlayersavedataTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of name method, of class Playersavedata.
     */
    @Test
    public void testName() {
        System.out.println("name");
        Playersavedata instance = null;
        String expResult = "";
        String result = instance.name();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of gamesplayed method, of class Playersavedata.
     */
    @Test
    public void testGamesplayed() {
        System.out.println("gamesplayed");
        Playersavedata instance = null;
        Integer expResult = null;
        Integer result = instance.gamesplayed();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of gameswon method, of class Playersavedata.
     */
    @Test
    public void testGameswon() {
        System.out.println("gameswon");
        Playersavedata instance = null;
        Integer expResult = null;
        Integer result = instance.gameswon();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of winpercent method, of class Playersavedata.
     */
    @Test
    public void testWinpercent() {
        System.out.println("winpercent");
        Playersavedata instance = null;
        Integer expResult = null;
        Integer result = instance.winpercent();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateGamesPlayed method, of class Playersavedata.
     */
    @Test
    public void testUpdateGamesPlayed() {
        System.out.println("updateGamesPlayed");
        Playersavedata instance = null;
        instance.updateGamesPlayed();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateGamesWon method, of class Playersavedata.
     */
    @Test
    public void testUpdateGamesWon() {
        System.out.println("updateGamesWon");
        Playersavedata instance = null;
        instance.updateGamesWon();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of get_players method, of class Playersavedata.
     */
    @Test
    public void testGet_players() {
        System.out.println("get_players");
        ArrayList<Playersavedata> expResult = null;
        ArrayList<Playersavedata> result = Playersavedata.get_players();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Update_Player method, of class Playersavedata.
     */
    @Test
    public void testUpdate_Player() {
        System.out.println("Update_Player");
        Playersavedata instance = null;
        instance.Update_Player();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
